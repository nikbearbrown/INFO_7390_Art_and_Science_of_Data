import streamlit as st
from streamlit_chat import message
from pinecone import Pinecone, ServerlessSpec
from sentence_transformers import SentenceTransformer

# Pinecone Configuration
PINECONE_API_KEY = "pcsk_4UnUtz_GX8H2actuQQud7t7XU5rfVeLVBZYVyyH7aVvqwA9q9sFoJenB7eVE7cihSHMKQe"
INDEX_NAME = "mediqueryx"
DIMENSION = 768  # Adjust based on your embedding model

# Initialize Pinecone
pc = Pinecone(api_key=PINECONE_API_KEY, environment="us-east-1")

# Check if the index exists, and create it if it doesn't
if INDEX_NAME not in pc.list_indexes().names():
    pc.create_index(
        name=INDEX_NAME,
        dimension=DIMENSION,
        metric="cosine",
        spec=ServerlessSpec(cloud="aws", region="us-east-1")
    )
index = pc.Index(INDEX_NAME)

# Load the embedding model
model = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")

# Example data to populate the index
documents = [
    {"id": "1", "text": "To lose weight, maintain a calorie deficit.", "context": "Weight loss tips"},
    {"id": "2", "text": "Drink plenty of water for better health.", "context": "Hydration advice"},
    {"id": "3", "text": "Exercise regularly to stay fit and healthy.", "context": "Fitness tips"}
]

# Create embeddings and add to Pinecone
for doc in documents:
    embedding = model.encode(doc["text"]).tolist()
    index.upsert([{"id": doc["id"], "values": embedding, "metadata": {"context": doc["context"]}}])



# Streamlit App Title and Description
st.title("MediQueryX Chatbot")
st.subheader("A Simple Chatbot Powered by Pinecone")

# Initialize Session State
if "responses" not in st.session_state:
    st.session_state["responses"] = ["Hi! How can I assist you today?"]

if "requests" not in st.session_state:
    st.session_state["requests"] = []

# Function to Query Pinecone
def query_pinecone(user_query):
    """
    Query the Pinecone index and return the best match.
    """
    try:
        # Generate the embedding for the user's query
        query_embedding = model.encode(user_query).tolist()

        # Query Pinecone with the embedding
        results = index.query(vector=query_embedding, top_k=1, include_metadata=True)

        # Check and return the top result's context
        if results["matches"]:
            return results["matches"][0]["metadata"].get("context", "No context found.")
        else:
            return "Sorry, I couldn't find any relevant information."
    except Exception as e:
        return f"Error querying Pinecone: {e}"

# UI Containers
response_container = st.container()
text_container = st.container()

# Text Input for User Query
with text_container:
    user_query = st.text_input("Your Question:", key="input")
    if user_query:
        with st.spinner("Searching..."):
            # Query Pinecone
            response = query_pinecone(user_query)
        # Update Session State
        st.session_state.requests.append(user_query)
        st.session_state.responses.append(response)

# Display Chat History
with response_container:
    if st.session_state["responses"]:
        for i in range(len(st.session_state["responses"])):
            if i < len(st.session_state["requests"]):
                message(st.session_state["requests"][i], is_user=True, key=f"{i}_user")
            message(st.session_state["responses"][i], key=f"{i}")